import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;
import javax.swing.text.Element;
import java.util.Locale;
import java.awt.Component;



public class Okno extends JFrame implements ActionListener, ListSelectionListener {

    Zamowienie z;
    Vector<Zamowienie> dane = new Vector<>();
    JButton dodaj = new JButton("Dodaj do listy zamowien");
    JButton dodajTowar = new JButton("Dodaj do listy towarów");
    JButton edytuj = new JButton("Edytuj zamowienie");
    JButton edytujTowar = new JButton("Edytuj składnik zamówienia");
    JButton usun = new JButton("Usuń");
    JButton wyszukujPoNazwie = new JButton("Wyszukuj po nazwie");
    JTextField wyszukiwanaNazwa = new JTextField(10);
    JButton wyszukujZTowarem = new JButton("Wyszukaj z dodanymi towarami");
    JButton wyszukujBezTowaru = new JButton("Wyszukuj bez dodanych towarów");
    JButton usunTowar = new JButton("Usun towar");
    JPanel panelDolny = new JPanel();

    JPanel p1 = new JPanel();
    JList lista = new JList(dane);
    JScrollPane sp = new JScrollPane(lista);
    JLabel zamowienieNazwa = new JLabel();
    JLabel zamowienieNazwaKontrahenta = new JLabel();
    JTextArea daneTowarow = new JTextArea(20, 50);

    JScrollPane spT = new JScrollPane(daneTowarow);
    JPanel panelPrawa = new JPanel(new GridLayout(2,1));
    JPanel panelPrawaGora = new JPanel(new GridLayout(1,2));
    public Okno(Zamowienie z){
        super("Obsługa zamówień");
        this.z=z;
    }
    public void init(){
        //podstawowe rzeczy:
        setVisible(true);
        setSize(1000, 500);
        setResizable(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        //stylizowanie listy po lewej
        sp.setBorder(new LineBorder(Color.DARK_GRAY));
        lista.setBorder(new TitledBorder("Lista zamówień:"));
        sp.setBackground(Color.CYAN);
        lista.setBackground(Color.CYAN);
        //lista.setSize(200,500);
        add(BorderLayout.WEST, sp);

        daneTowarow.setEditable(false);

        //dodanie panelu po prawej
        panelPrawaGora.add(zamowienieNazwa);
        panelPrawaGora.add(zamowienieNazwaKontrahenta);
        panelPrawaGora.setPreferredSize(new Dimension(500,100));
        zamowienieNazwa.setBorder(new TitledBorder(new LineBorder(Color.DARK_GRAY), "Nazwa zamówienia: "));
        zamowienieNazwaKontrahenta.setBorder(new TitledBorder(new LineBorder(Color.DARK_GRAY), "Nazwa kontrahenta: "));
        panelPrawa.add(panelPrawaGora);
        panelPrawa.add(spT);
        panelPrawa.setVisible(false);
        //daneTowarow.setBorder(new TitledBorder("Składniki zamówienia: "));
        add(BorderLayout.EAST, panelPrawa);




        //dodanie listenerow
        dodaj.addActionListener(this);
        dodajTowar.addActionListener(this);
        usun.addActionListener(this);
        edytuj.addActionListener(this);
        edytujTowar.addActionListener(this);
        lista.addListSelectionListener(this);
        usunTowar.addActionListener(this);

        //dodanie elementow do panela
        p1.setLayout(new GridLayout(6,1));
        p1.add(dodaj);
        p1.add(dodajTowar);
        p1.add(edytuj);
        p1.add(edytujTowar);
        p1.add(usunTowar);
        p1.add(usun);
        //i panela do okna
        add(p1, BorderLayout.CENTER);

        //panel dolny
        panelDolny.setLayout(new FlowLayout());
        panelDolny.add(wyszukujPoNazwie);
        panelDolny.add(wyszukiwanaNazwa);
        panelDolny.add(wyszukujZTowarem);
        panelDolny.add(wyszukujBezTowaru);

        add(panelDolny, BorderLayout.SOUTH);

        wyszukujPoNazwie.addActionListener(this);
        wyszukujZTowarem.addActionListener(this);
        wyszukujBezTowaru.addActionListener(this);

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        Object akcja = e.getSource();

        //dodawanie zamowienia do listy
        if(akcja == dodaj){
            String nazwa = JOptionPane.showInputDialog("Podaj nazwę zamówienia:");
            String nazwaK = JOptionPane.showInputDialog("Podaj nazwę kontrahenta:");
            dane.add(new Zamowienie(nazwa, nazwaK));
            lista.setListData(dane);

         //dodanie towaru
        } else if (akcja == dodajTowar) {
            try {
                int index1 = lista.getSelectedIndex();
                if (index1 >= 0) {
                    String nazwaTowaru = JOptionPane.showInputDialog("Podaj nazwę towaru:");
                    double cenaNettoTowaru = Double.parseDouble(JOptionPane.showInputDialog("Podaj cenę netto towaru:"));
                    int stawkaVatTowaru = Integer.parseInt(JOptionPane.showInputDialog("Podaj stawkę vat towaru:"));
                    int iloscTowaru = Integer.parseInt(JOptionPane.showInputDialog("Podaj ilość towaru:"));

                    dane.elementAt(index1).dodajTowar(new Towar(nazwaTowaru, cenaNettoTowaru, stawkaVatTowaru, iloscTowaru));
                    //System.out.println(dane.elementAt(index1).listaTowarow.elementAt(0).getNazwa());
                    // lista.setListData(dane);
                    lista.setListData(dane);
                    //daneTowarow.setText(t.getNazwa() + " " + t.getCenaNetto()+ " " + t.getIlosc() + " " + t.getStawkaVat() +  "\n");
                    lista.setSelectedIndex(index1);
                } else {
                    JOptionPane.showMessageDialog(null, "Nie wybrales zamówienia", "Błąd", JOptionPane.WARNING_MESSAGE);
                }
            }
            catch (Exception e2){
                JOptionPane.showMessageDialog(null, "Błędne dane", "Błąd",JOptionPane.WARNING_MESSAGE);
            }

            //edytowanie zamówienia na liście
        } else if (akcja == edytuj) {
                int index = lista.getSelectedIndex();

                if(index >= 0){
                    String nazwa = JOptionPane.showInputDialog("Podaj nową nazwę zamówienia:");
                    String nazwaK = JOptionPane.showInputDialog("Podaj nową nazwę kontrahenta:");
                    dane.elementAt(index).setNazwa(nazwa);
                    dane.elementAt(index).setNazwaKontrahenta(nazwaK);
                    lista.setListData(dane);
                    lista.setSelectedIndex(index);
                }
                else{
                    JOptionPane.showMessageDialog(null, "Nie wybrales zamówienia", "Błąd",JOptionPane.WARNING_MESSAGE);
                }
                //edycja towaru
        } else if (akcja == edytujTowar) {
            String nazwaTowaru;
            double cenaNettoTowaru;
            int stawkaVatTowaru;
            int iloscTowaru;

            try {
                int index1 = lista.getSelectedIndex();
                if (index1 >= 0) {
                    int index = Integer.parseInt(JOptionPane.showInputDialog("Podaj index towaru do zmiany:"));
                    if(index <= dane.elementAt(index1).getListaTowarow().size()) {
                        nazwaTowaru = JOptionPane.showInputDialog("Podaj nazwę towaru:");
                        cenaNettoTowaru = Double.parseDouble(JOptionPane.showInputDialog("Podaj cenę netto towaru:"));
                        stawkaVatTowaru = Integer.parseInt(JOptionPane.showInputDialog("Podaj stawkę vat towaru:"));
                        iloscTowaru = Integer.parseInt(JOptionPane.showInputDialog("Podaj ilość towaru:"));
                    }else{
                        JOptionPane.showMessageDialog(null, "Błędny index", "Błąd",JOptionPane.WARNING_MESSAGE);
                        return;
                    }

                    dane.elementAt(index1).getListaTowarow().elementAt(index-1).setNazwa(nazwaTowaru);//dodajTowar(new Towar(nazwaTowaru, cenaNettoTowaru, stawkaVatTowaru, iloscTowaru));
                    dane.elementAt(index1).getListaTowarow().elementAt(index-1).setCenaNetto(cenaNettoTowaru);
                    dane.elementAt(index1).getListaTowarow().elementAt(index-1).setStawkaVat(stawkaVatTowaru);
                    dane.elementAt(index1).getListaTowarow().elementAt(index-1).setIlosc(iloscTowaru);




                    lista.setListData(dane);

                    lista.setSelectedIndex(index1);
                } else {
                    JOptionPane.showMessageDialog(null, "Nie wybrales zamówienia", "Błąd", JOptionPane.WARNING_MESSAGE);
                }
            }
            catch (Exception e2){
                JOptionPane.showMessageDialog(null, "Błędne dane", "Błąd",JOptionPane.WARNING_MESSAGE);
            }


            //usuwanie elementu
        } else if (akcja == usunTowar) {
            try {
                int index1 = lista.getSelectedIndex();
                if (index1 >= 0) {
                    int index = Integer.parseInt(JOptionPane.showInputDialog("Podaj index towaru do usunięcia:"));
                    if(index <= dane.elementAt(index1).getListaTowarow().size()) {
                        dane.elementAt(index1).getListaTowarow().removeElementAt(index-1);
                        lista.setListData(dane);
                        lista.setSelectedIndex(index1);
                    }else{
                        JOptionPane.showMessageDialog(null, "Błędny index", "Błąd",JOptionPane.WARNING_MESSAGE);
                        return;
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "Nie wybrales zamówienia z którego chcesz usunąć index", "Błąd", JOptionPane.WARNING_MESSAGE);
                }
            }
            catch (Exception e2){
                JOptionPane.showMessageDialog(null, "Błędne dane", "Błąd",JOptionPane.WARNING_MESSAGE);
            }


        }else if (akcja == usun) {
                int index = lista.getSelectedIndex();
                if(index >= 0){
                   dane.removeElementAt(index);
                    lista.setListData(dane);
                    lista.setSelectedIndex(-1);


        } else{
                    if(dane.isEmpty()){
                        JOptionPane.showMessageDialog(null, "Lista pusta", "Błąd",JOptionPane.WARNING_MESSAGE);
                    }else{
                        JOptionPane.showMessageDialog(null, "Nie wybrano elementu", "Błąd",JOptionPane.WARNING_MESSAGE);
                    }

                }
                if(dane.isEmpty()){
                    panelPrawa.setVisible(false);
                }
            //od tąd sprawdzać
            //wyszukiwanie po nazwie zamowienia:
        }else if (akcja == wyszukujPoNazwie) {
                 String nazwa = wyszukiwanaNazwa.getText();
                 //System.out.println(nazwa);
                for (int i = 0; i < dane.size(); i++){
                    Zamowienie z = dane.elementAt(i);
                    //System.out.println(i);
                    if (nazwa.equals(z.getNazwa()) ){
                        zamowienieNazwa.setText(z.getNazwa());
                        zamowienieNazwaKontrahenta.setText(z.getNazwaKontrahenta());
                        String tmp= "";
                        for(Towar t : z.getListaTowarow()){
                            tmp += "Nazwa Towaru: "+t.getNazwa() + " Cena netto towaru: " + t.getCenaNetto()+ " Ilosc: " + t.getIlosc() + " Stawka vat: " + t.getStawkaVat() + " \n";
                        }
                        daneTowarow.setText(tmp);
                    }
                }
                //wyszukuje pierwsze zamowienie bez towaru
            } else if (akcja == wyszukujBezTowaru) {
                for (Zamowienie z : dane){
                    if(z.getListaTowarow().isEmpty()){
                        zamowienieNazwa.setText(z.getNazwa());
                        zamowienieNazwaKontrahenta.setText(z.getNazwaKontrahenta());
                        daneTowarow.setText("");
                        break;
                    }
                }
                //wyszukuje pierwsze zamowienie z toarem
            } else if (akcja == wyszukujZTowarem) {
                for (Zamowienie z : dane){
                    if(z.getListaTowarow().size()>0){
                        zamowienieNazwa.setText(z.getNazwa());
                        zamowienieNazwaKontrahenta.setText(z.getNazwaKontrahenta());

                        String tmp1= "";
                        for(Towar t : z.getListaTowarow()){
                            tmp1 += "Nazwa Towaru: "+t.getNazwa() + " Cena netto towaru: " + t.getCenaNetto()+ " Ilosc: " + t.getIlosc() + " Stawka vat: " + t.getStawkaVat() + " \n";
                        }
                        daneTowarow.setText(tmp1);
                        break;
                    }
                }
            }
    }



    @Override
    public void valueChanged(ListSelectionEvent e) {
        int wybor = lista.getSelectedIndex();
        if(wybor >= 0){
            if (dane.elementAt(wybor).getListaTowarow().size() > 0) {
                //daneZamowienia.setVisible(false);
                zamowienieNazwa.setText(dane.elementAt(wybor).getNazwa());
                zamowienieNazwaKontrahenta.setText(dane.elementAt(wybor).getNazwaKontrahenta());
                String tmp= "";
                int i = 0;
                for(Towar t : dane.elementAt(wybor).getListaTowarow()){

                    i++;
                    tmp += "ID: " + i + " Nazwa Towaru: "+t.getNazwa() + " Cena netto towaru: " + t.getCenaNetto()+ " Ilosc: " + t.getIlosc() + " Stawka vat: " + t.getStawkaVat() + " \n";

                }
                panelPrawa.setVisible(true);
                daneTowarow.setText(tmp);


            }else {
                zamowienieNazwa.setText(dane.elementAt(wybor).getNazwa());
                zamowienieNazwaKontrahenta.setText(dane.elementAt(wybor).getNazwaKontrahenta());
                daneTowarow.setText("");
                panelPrawa.setVisible(true);
            }
        }

    }
}
