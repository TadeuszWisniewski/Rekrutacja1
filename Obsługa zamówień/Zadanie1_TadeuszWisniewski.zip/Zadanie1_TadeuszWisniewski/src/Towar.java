public class Towar {
    private int id;
    private String nazwa;
    private double cenaNetto;
    private int ilosc;
    private int stawkaVat;
    private static int idStatyczne;
    public Towar(String nazwa, double cenaNetto, int stawkaVat, int ilosc){
        this.nazwa=nazwa;
        this.cenaNetto = cenaNetto;
        this.stawkaVat = stawkaVat;
        this.ilosc = ilosc;
        idStatyczne++;
        id = idStatyczne;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public double getCenaNetto() {
        return cenaNetto;
    }

    public void setCenaNetto(double cenaNetto) {
        this.cenaNetto = cenaNetto;
    }

    public int getIlosc() {
        return ilosc;
    }

    public void setIlosc(int ilosc) {
        this.ilosc = ilosc;
    }

    public int getStawkaVat() {
        return stawkaVat;
    }

    public void setStawkaVat(int stawkaVat) {
        this.stawkaVat = stawkaVat;
    }

    public void wyswietlTowar(){
        System.out.println("ID: " + id + " Nazwa: " + nazwa + " Cena netto: " + cenaNetto + " Stawka vat: " + stawkaVat + " Ilość: " + ilosc);
    }
    public String getTowar(){
        return nazwa + " " + cenaNetto + " " + stawkaVat + " " + ilosc;
    }
}
