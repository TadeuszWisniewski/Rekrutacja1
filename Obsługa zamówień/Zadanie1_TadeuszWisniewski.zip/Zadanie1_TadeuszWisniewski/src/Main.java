public class Main {
    public static void main(String[] args) {

        System.out.println("Hello world!");

        Zamowienie z1 = new Zamowienie("Pierwsze", "Jakis gość");

        Okno okno = new Okno(z1);
        okno.init();
    }
}