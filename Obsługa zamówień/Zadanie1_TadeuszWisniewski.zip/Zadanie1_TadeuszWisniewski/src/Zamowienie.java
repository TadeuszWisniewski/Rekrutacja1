import javax.swing.*;
import java.util.ArrayList;
import java.util.Vector;

public class Zamowienie {
    private int id;
    private String nazwa;
    private String nazwaKontrahenta;
    private int pozycjaNaLiscie;
    public Vector<Towar> listaTowarow;

    private static int idStatyczne;

    public Zamowienie(String nazwa, String nazwaKontrahenta) {
        this.nazwa = nazwa;
        this.nazwaKontrahenta = nazwaKontrahenta;
        listaTowarow = new Vector<>();
        idStatyczne++;
        id=idStatyczne;
    }

    public int getId() {
        return id;
    }
    public String getNazwa() {
        return nazwa;
    }
    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }
    public String getNazwaKontrahenta() {
        return nazwaKontrahenta;
    }
    public void setNazwaKontrahenta(String nazwaKontrahenta) {
        this.nazwaKontrahenta = nazwaKontrahenta;
    }
    public int getPozycjaNaLiscie() {
        return pozycjaNaLiscie;
    }
    public void setPozycjaNaLiscie(int pozycjaNaLiscie) {
        this.pozycjaNaLiscie = pozycjaNaLiscie;
    }
    public void dodajTowar(Towar t){
        listaTowarow.add(t);
    }

    public Vector<Towar> getListaTowarow() {
        return listaTowarow;
    }

    public void setListaTowarow(Vector<Towar> listaTowarow) {
        this.listaTowarow = listaTowarow;
    }

    public void wyswietlZamowienie(){
        System.out.println("ID: " + id + " Nazwa: " + nazwa + " Pozycja na liscie " + pozycjaNaLiscie);
    }
    public Towar towarPodIndeksem(){
       return listaTowarow.get(0);
    }
}
