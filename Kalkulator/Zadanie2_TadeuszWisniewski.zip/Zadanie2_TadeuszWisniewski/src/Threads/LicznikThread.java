package Threads;

import Windows.KalkulatorWindow;

import javax.swing.*;
import java.util.Random;

public class LicznikThread extends Thread{
    KalkulatorWindow kalkulatorWindow;

    public KalkulatorWindow getKalkulatorWindow() {
        return kalkulatorWindow;
    }

    public LicznikThread(KalkulatorWindow kalkulatorWindow) {
        super();
        this.kalkulatorWindow = kalkulatorWindow;
    }

    @Override
    public void run() {
        try {
            //wylaczenie pol do wprowadzania
            getKalkulatorWindow().getWprowadzCzas().setEnabled(false);
            getKalkulatorWindow().getDolnyZakres().setEnabled(false);
            getKalkulatorWindow().getGornyZakres().setEnabled(false);
            getKalkulatorWindow().getLiczbaRund().setEnabled(false);
            //pobranie czasu
            String czasTMP = getKalkulatorWindow().getWprowadzCzas().getText();
            getKalkulatorWindow().getPozostalyCzasRundy().setText(czasTMP);

            //pobranie gorny zakresu
            int gornyTMP = Integer.parseInt(getKalkulatorWindow().getGornyZakres().getText());

            //pobranie dolny zakresu
            int dolnyTMP = Integer.parseInt(getKalkulatorWindow().getDolnyZakres().getText());

            //musze bo wyjątków nie ma w poleceniu to zamienie w razie czego
            if(dolnyTMP > gornyTMP){
                int tmp = dolnyTMP;
                dolnyTMP = gornyTMP;
                gornyTMP = tmp;
            }
            //pobranie liczby rund
            String liczbaRundTMP = getKalkulatorWindow().getLiczbaRund().getText();
            getKalkulatorWindow().getPozostalaLiczbaRund().setText(liczbaRundTMP);

            //pokazanie trafnych trafien:
            int trafne = Integer.parseInt(liczbaRundTMP);

            //pobranie liczby rund do int
            int los1, los2;

            try{
                getKalkulatorWindow().getPowodzenia().setText("Powodzenia!!");
                int rundy = 1;
                while(rundy > 0) {
                    getKalkulatorWindow().getWprowadzWynik().setText("");
                    rundy=Integer.parseInt(getKalkulatorWindow().getPozostalaLiczbaRund().getText());

                    los1 = losuj(dolnyTMP, gornyTMP);
                    los2 = losuj(dolnyTMP, gornyTMP);
                    getKalkulatorWindow().getDzialaniaDoWykonania().setText(los1 + " * " + los2);

                    int sekundy = 1;
                    while (sekundy > 0) {

                        sekundy = Integer.parseInt(getKalkulatorWindow().getPozostalyCzasRundy().getText());
                        Thread.sleep(1000);
                        sekundy--;

                        getKalkulatorWindow().getPozostalyCzasRundy().setText(sekundy + "");
                        //if (sekundy==0){
                          //  break;
                       // }
                    }

                    if((getKalkulatorWindow().getWprowadzWynik().getText()).equals("")){
                        getKalkulatorWindow().getWprowadzWynik().setText(0+"");
                    }
                    if (los1 * los2 == Integer.parseInt(getKalkulatorWindow().getWprowadzWynik().getText())) {
                        getKalkulatorWindow().getPowodzenia().setText("Trafiony");
                    } else {
                        getKalkulatorWindow().getPowodzenia().setText("Pudło");
                        trafne--;
                    }
                    getKalkulatorWindow().getWprowadzWynik().setText("");

                    //ustawienie innej liczby rund
                    rundy--;
                    getKalkulatorWindow().getPozostalaLiczbaRund().setText(rundy+"");
                    getKalkulatorWindow().getPozostalyCzasRundy().setText(czasTMP);
                }
                getKalkulatorWindow().getPowodzenia().setText("Trafione: " + trafne + " z " + liczbaRundTMP);
                getKalkulatorWindow().getWprowadzCzas().setEnabled(true);
                getKalkulatorWindow().getDolnyZakres().setEnabled(true);
                getKalkulatorWindow().getGornyZakres().setEnabled(true);
                getKalkulatorWindow().getLiczbaRund().setEnabled(true);
            }catch (Exception e){
                System.out.println("Gdzieś wprowadzono stringa zamiast liczby-nie było w poleciu nic o obsłudze wyjątków to tylko wypiszę :)");
            }
        }catch (Exception exc){
            System.out.println("Gdzieś wprowadzono stringa zamiast liczby-nie było w poleciu nic o obsłudze wyjątków to tylko wypiszę :)");
        }
    }
    public int losuj(int dolny, int gorny){
        Random rndD = new Random();
        int zwrot;
        zwrot = rndD.nextInt(gorny-dolny)+dolny;
        return zwrot;
    }
}
