
import Windows.KalkulatorWindow;

public class Main {
    public static void main(String[] args) {

        System.out.println("Hello world!");
        KalkulatorWindow kw = new KalkulatorWindow();

    }
}