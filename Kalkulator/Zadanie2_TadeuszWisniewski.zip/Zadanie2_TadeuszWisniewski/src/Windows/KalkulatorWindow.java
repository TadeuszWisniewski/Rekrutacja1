package Windows;

import Listeners.KalkulatorListener;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class KalkulatorWindow extends JFrame {

    private JButton start;
    private JTextField wprowadzCzas;
    private JTextField dolnyZakres;
    private JTextField gornyZakres;
    private JTextField liczbaRund;
    private JTextField dzialaniaDoWykonania;
    private JLabel pozostalyCzasRundy;
    private JLabel pozostalaLiczbaRund;
    private JTextField wprowadzWynik;
    private JLabel powodzenia;
    public JButton getStart() {
        return start;
    }

    public JTextField getWprowadzCzas() {
        return wprowadzCzas;
    }

    public JTextField getDolnyZakres() {
        return dolnyZakres;
    }

    public JTextField getGornyZakres() {
        return gornyZakres;
    }

    public JTextField getLiczbaRund() {
        return liczbaRund;
    }

    public JTextField getDzialaniaDoWykonania() {
        return dzialaniaDoWykonania;
    }

    public JLabel getPozostalyCzasRundy() {
        return pozostalyCzasRundy;
    }

    public JLabel getPozostalaLiczbaRund() {
        return pozostalaLiczbaRund;
    }

    public JTextField getWprowadzWynik() {
        return wprowadzWynik;
    }

    public JLabel getPowodzenia() {
        return powodzenia;
    }

    public KalkulatorWindow(){
        super("Kalkulator");
        setSize(500, 500);
        setContentPane(new KalkulatorWindowContent(this));
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    class KalkulatorWindowContent extends JPanel{

        public KalkulatorWindowContent(KalkulatorWindow kalkulatorWindow){
            setLayout(new GridLayout(5,3));
            //pola po lewej

            wprowadzCzas = new JTextField();
            wprowadzCzas.setBorder(new TitledBorder(new LineBorder(Color.BLACK), "Czas 1 rundy:"));
            dolnyZakres = new JTextField();
            dolnyZakres.setBorder(new TitledBorder(new LineBorder(Color.BLACK), "Dolny zakres losowania:"));
            gornyZakres = new JTextField();
            gornyZakres.setBorder(new TitledBorder(new LineBorder(Color.BLACK), "Górny zakres losowania:"));
            liczbaRund = new JTextField();
            liczbaRund.setBorder(new TitledBorder(new LineBorder(Color.BLACK), "Liczba rund:"));
            start = new JButton("Start");
            start.addActionListener(new KalkulatorListener(kalkulatorWindow));

           //pola z prawej
            dzialaniaDoWykonania = new JTextField("Jeszcze brak dzialania");
            dzialaniaDoWykonania.setHorizontalAlignment(JTextField.CENTER);
            dzialaniaDoWykonania.setBorder(new TitledBorder(new LineBorder(Color.BLACK), "Oblicz to:"));
            dzialaniaDoWykonania.setEnabled(false);
            pozostalyCzasRundy = new JLabel("Jeszcze nic");
            pozostalyCzasRundy.setBorder(new TitledBorder(new LineBorder(Color.BLACK), "Pozostały czas:"));
            pozostalyCzasRundy.setHorizontalAlignment(JTextField.CENTER);
            pozostalaLiczbaRund = new JLabel("Jeszcze nic");
            pozostalaLiczbaRund.setBorder(new TitledBorder(new LineBorder(Color.BLACK), "Pozostało rund:"));
            pozostalaLiczbaRund.setHorizontalAlignment(JTextField.CENTER);

            //pola srodek
            wprowadzWynik = new JTextField("Wprowadz wynik i czekaj ");
            wprowadzWynik.setBorder(new TitledBorder(new LineBorder(Color.BLACK), "Wprowadz wynik:"));
            powodzenia = new JLabel("Powodzenia!! ");
            powodzenia.setHorizontalAlignment(JTextField.CENTER);

            //dodanie wszystkiego
            add(wprowadzCzas);
            add(wprowadzWynik);
            add(dzialaniaDoWykonania);
            add(dolnyZakres);
            add(powodzenia);
            add(pozostalyCzasRundy);
            add(gornyZakres);
            add(new JPanel());
            add(pozostalaLiczbaRund);
            add(liczbaRund);
            add(new JPanel());
            add(new JPanel());
            add(start);

        }
    }

}
