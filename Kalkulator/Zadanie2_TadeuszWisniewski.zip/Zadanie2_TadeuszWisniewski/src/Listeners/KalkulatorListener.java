package Listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import Windows.KalkulatorWindow;
import Threads.LicznikThread;

public class KalkulatorListener implements ActionListener {

    private final KalkulatorWindow kalkulatorWindow;
    public LicznikThread licznik;


    public KalkulatorWindow getKalkulatorWindow() {
        return kalkulatorWindow;
    }

    public KalkulatorListener(KalkulatorWindow kalkulatorWindow) {
        this.kalkulatorWindow = kalkulatorWindow;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object akcja = e.getSource();

        if(akcja==getKalkulatorWindow().getStart()) {
            //pobranie liczby rund
            String liczbaRundTMP = getKalkulatorWindow().getLiczbaRund().getText();
            getKalkulatorWindow().getPozostalaLiczbaRund().setText(liczbaRundTMP);
            //start wątku
            licznik = new LicznikThread(getKalkulatorWindow());
            licznik.start();

        }
    }
}
