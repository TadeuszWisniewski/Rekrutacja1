import java.io.*;
import java.net.ServerSocket;
public class Serwer {
    public static final int SERVER_PORT = 2002;
    public static final String KONIEC_POLACZENIA = "KONIEC POLACZENIA";
    private ServerSocket serverSocket;


    public ServerSocket getServerSocket() {
        return serverSocket;
    }

    public void setServerSocket(ServerSocket serverSocket) {
        this.serverSocket = serverSocket;
    }
    public  Serwer(){
        try{
            serverSocket=new ServerSocket(SERVER_PORT);
            System.out.println("Serwer dziala");
        }catch(IOException ex){
            System.out.println("Nie mozna utworzyc gniazda");
        }
    }
    public void uruchom(){
        try {
            while (true) {
                System.out.println("Czekam na klientów...");
                new Rozmowa(getServerSocket().accept(), getServerSocket().accept());
            }
        } catch (IOException e) {
            System.out.println("Błąd przy tworzeniu soketa");
        }
    }
}
