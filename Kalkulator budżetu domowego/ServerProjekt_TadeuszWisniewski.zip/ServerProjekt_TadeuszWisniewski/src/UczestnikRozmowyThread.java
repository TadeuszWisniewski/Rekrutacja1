import java.io.*;
import java.net.Socket;
public class UczestnikRozmowyThread extends Thread{
    private Socket socket;
    private PrintWriter writer;
    private BufferedReader reader;
    private UczestnikRozmowyThread drugiUczestnikRozmowy;

    public UczestnikRozmowyThread getDrugiUczestnikRozmowy() {
        return drugiUczestnikRozmowy;
    }

    public void setDrugiUczestnikRozmowy(UczestnikRozmowyThread drugiUczestnikRozmowy) {
        this.drugiUczestnikRozmowy = drugiUczestnikRozmowy;
    }

    public Socket getSocket() {
        return socket;
    }

    public PrintWriter getWriter() {
        return writer;
    }

    public BufferedReader getReader() {
        return reader;
    }

    public UczestnikRozmowyThread(Socket socket) {
        this.socket = socket;
        try{
            writer = new PrintWriter(
                    new BufferedWriter(
                            new OutputStreamWriter(socket.getOutputStream())), true);
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        }catch(IOException e){
            System.out.println("Wystąpił błąd przy otwieraniu połączenia z serwerem\n");
        }
    }
    @Override
    public void run(){
        try {
            String linia;
            while((linia = getReader().readLine()) != null) {
                if (linia.equals(Serwer.KONIEC_POLACZENIA)) {
                    break;
                }
                getDrugiUczestnikRozmowy().getWriter().println(linia);
            }
        } catch (IOException ex) {
        }

        try{
            getWriter().close();
            getReader().close();
            getSocket().close();
        }catch (IOException ex){
            System.out.println("Błąd przy zamykaniu połączenia");
        }
    }
}
