import java.net.Socket;

public class Rozmowa {
    public Rozmowa(Socket klient1, Socket klient2){
        UczestnikRozmowyThread uczestnik1, uczestnik2;
        uczestnik1 = new UczestnikRozmowyThread(klient1);
        uczestnik2 = new UczestnikRozmowyThread(klient2);
        uczestnik1.setDrugiUczestnikRozmowy(uczestnik2);
        uczestnik2.setDrugiUczestnikRozmowy(uczestnik1);
        uczestnik1.start();
        uczestnik2.start();
    }
}
