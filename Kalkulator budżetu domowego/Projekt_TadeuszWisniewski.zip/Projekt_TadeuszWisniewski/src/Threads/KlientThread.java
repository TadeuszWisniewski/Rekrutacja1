package Threads;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;

public class KlientThread extends Thread implements ActionListener {
    public static final int SERVER_PORT = 2002;


    private Socket socket;
    private BufferedReader reader;
    private PrintWriter writer;
    private JTextField output;
    private JTextField input;

    public KlientThread(JTextField output, JTextField input) {
        this.output = output;
        this.input = input;
        try{
            socket = new Socket("localhost", SERVER_PORT);
            writer = new PrintWriter(
                    new BufferedWriter(
                            new OutputStreamWriter(socket.getOutputStream())), true);
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            init();
        }catch(IOException e){
            output.setText("Wystąpił błąd przy otwieraniu połączenia z serwerem\n");
        }
    }

    public Socket getSocket() {
        return socket;
    }

    public BufferedReader getReader() {
        return reader;
    }

    public PrintWriter getWriter() {
        return writer;
    }

    public JTextField getOutput() {
        return output;
    }

    public JTextField getInput() {
        return input;
    }

    public void init(){
        start();
    }
    @Override
    public void run(){
        try {
            String linia;
            while((linia = getReader().readLine()) != null) {



                getOutput().setText(linia);
            }
        } catch (IOException ex) {

        }

        try{
            getWriter().close();
            getReader().close();
            getSocket().close();
        }catch (IOException ex){
            System.out.println("Błąd przy zamykaniu połączenia");
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            writer.println(getInput().getText());
        }catch(Exception ex){
            System.out.println("Błąd przy wysyłaniu informacji");
        }
    }
}
