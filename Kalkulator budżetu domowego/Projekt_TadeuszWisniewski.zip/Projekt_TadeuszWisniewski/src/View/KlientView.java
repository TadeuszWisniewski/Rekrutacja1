package View;

import Listeners.BudzetListener;
import Models.WydatkiKontener;
import Threads.KlientThread;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class KlientView extends JFrame {
    //kontener wydatkow
    private WydatkiKontener wydatkiKontener = new WydatkiKontener();

    public WydatkiKontener getWydatkiKontener() {
        return wydatkiKontener;
    }

    private JTextArea mojeWydatkiLewa;
    private JScrollPane mojeWydatkiLewaScrol;
    private JTextField mojeDochodyLewa;
    private JLabel wydatkiWspolneSrodekZPliku;
    private JPanel wszystkiePrzyciskiSrodekPanel;
    private JTextField partneraWydatkiPrawa;
    private JScrollPane partneraWydatkiPrawaScroll;
    private JPanel panelPrawaDol;

    private  JButton buttonDodajWydatki;
    private JTextField kwotaWydatku;
    private JPanel grupaPrzyciskowWydatekPanel;
        //przyciski do panelu powyzej
        private JRadioButton radioButtonZywnosc;
        private JRadioButton radioButtonMieszkanie;
        private JRadioButton radioButtonInne;
        private ButtonGroup grupaRadioButtonowWydatek;
    private JButton buttonDodajDochody;
    private JTextField kwotaDochodu;
    private JButton buttonWyczyscDochody;
    private JButton buttonUsunWydatek;
    private JButton buttonWyslijDoPliku;
    private JButton buttonWyczyscWydatki;
    private JPanel panelLewaDol;
    private JTextField textFieldLewaDolPodsumowanieWydatkow;
    private JLabel podsumowanieLewaDol;
    private JButton buttonPodsumowanieLewaDol;
    private JPanel panelLewaDolDol;
    private JButton buttonPobierzOdPartnera;
    private JTextArea textFieldPanelSrodekDolPrawy;
    public JTextField getTextFieldLewaDolPodsumowanieWydatkow() {
        return textFieldLewaDolPodsumowanieWydatkow;
    }

    public JTextArea getTextFieldPanelSrodekDolPrawy() {
        return textFieldPanelSrodekDolPrawy;
    }

    public JButton getButtonPobierzOdPartnera() {
        return buttonPobierzOdPartnera;
    }

    public JPanel getPanelLewaDolDol() {
        return panelLewaDolDol;
    }

    public JButton getButtonPodsumowanieLewaDol() {
        return buttonPodsumowanieLewaDol;
    }

    public JLabel getPodsumowanieLewaDol() {
        return podsumowanieLewaDol;
    }

    public JPanel getPanelLewaDol() {
        return panelLewaDol;
    }

    public JTextArea getMojeWydatkiLewa() {
        return mojeWydatkiLewa;
    }

    public JScrollPane getMojeWydatkiLewaScrol() {
        return mojeWydatkiLewaScrol;
    }

    public JTextField getMojeDochodyLewa() {
        return mojeDochodyLewa;
    }

    public JLabel getWydatkiWspolneSrodekZPliku() {
        return wydatkiWspolneSrodekZPliku;
    }

    public JPanel getWszystkiePrzyciskiSrodekPanel() {
        return wszystkiePrzyciskiSrodekPanel;
    }

    public JTextField getPartneraWydatkiPrawa() {
        return partneraWydatkiPrawa;
    }

    public JScrollPane getPartneraWydatkiPrawaScroll() {
        return partneraWydatkiPrawaScroll;
    }

    public JPanel getPanelPrawaDol() {
        return panelPrawaDol;
    }

    public JButton getButtonDodajWydatki() {
        return buttonDodajWydatki;
    }

    public JTextField getKwotaWydatku() {
        return kwotaWydatku;
    }

    public JPanel getGrupaPrzyciskowWydatekPanel() {
        return grupaPrzyciskowWydatekPanel;
    }

    public JRadioButton getRadioButtonZywnosc() {
        return radioButtonZywnosc;
    }

    public JRadioButton getRadioButtonMieszkanie() {
        return radioButtonMieszkanie;
    }

    public JRadioButton getRadioButtonInne() {
        return radioButtonInne;
    }

    public ButtonGroup getGrupaRadioButtonowWydatek() {
        return grupaRadioButtonowWydatek;
    }

    public JButton getButtonDodajDochody() {
        return buttonDodajDochody;
    }

    public JTextField getKwotaDochodu() {
        return kwotaDochodu;
    }

    public JButton getButtonWyczyscDochody() {
        return buttonWyczyscDochody;
    }

    public JButton getButtonUsunWydatek() {
        return buttonUsunWydatek;
    }

    public JButton getButtonWyslijDoPliku() {
        return buttonWyslijDoPliku;
    }

    public JButton getButtonWyczyscWydatki() {
        return buttonWyczyscWydatki;
    }

    public KlientView(){
      super("Budżet domowy");
      setSize(1500, 500);
      setContentPane(new KlientViewContent(this));
      setVisible(true);
      setResizable(false);
      setDefaultCloseOperation(EXIT_ON_CLOSE);
    }



    class KlientViewContent extends JPanel{
      public KlientViewContent(KlientView klientView){
          setLayout(new GridLayout(2,3));

          mojeWydatkiLewa = new JTextArea();
          mojeWydatkiLewaScrol = new JScrollPane(mojeWydatkiLewa);
          mojeDochodyLewa = new JTextField();
          wydatkiWspolneSrodekZPliku=new JLabel();
          wszystkiePrzyciskiSrodekPanel = new JPanel();
          partneraWydatkiPrawa = new JTextField();
          partneraWydatkiPrawaScroll = new JScrollPane(partneraWydatkiPrawa);
          panelPrawaDol = new JPanel();//dodac
          panelPrawaDol.setLayout(new GridLayout(2,2));
          panelLewaDol = new JPanel();//dodac
          textFieldLewaDolPodsumowanieWydatkow=new JTextField();
          podsumowanieLewaDol = new JLabel();//dodac
          buttonPodsumowanieLewaDol = new JButton("Pokaz podsumowanie");//dodac
          panelLewaDolDol = new JPanel();//dodac
          buttonPobierzOdPartnera = new JButton("Wyślij do partnera");
          buttonPobierzOdPartnera.addActionListener(new KlientThread(getPartneraWydatkiPrawa(), getTextFieldLewaDolPodsumowanieWydatkow()));


          //panel srodek dol grid
          buttonDodajWydatki = new JButton("Dodaj");
          buttonDodajWydatki.addActionListener(new BudzetListener(klientView));
          kwotaWydatku = new JTextField();
          grupaPrzyciskowWydatekPanel = new JPanel();
          textFieldPanelSrodekDolPrawy = new JTextArea();

            //radioButtony do tego panelu:
            radioButtonZywnosc = new JRadioButton("Żywność");
            radioButtonMieszkanie = new JRadioButton("Mieszkanie");
            radioButtonInne = new JRadioButton("Inne");
            grupaRadioButtonowWydatek = new ButtonGroup();

            //dodanie do tej grupy:
            grupaRadioButtonowWydatek.add(radioButtonZywnosc);
            grupaRadioButtonowWydatek.add(radioButtonMieszkanie);
            grupaRadioButtonowWydatek.add(radioButtonInne);

          buttonDodajDochody = new JButton("Dodaj dochody");
          buttonDodajDochody.addActionListener(new BudzetListener(klientView));
          kwotaDochodu = new JTextField();
          buttonWyczyscDochody = new JButton("Wyczyść");
          buttonWyczyscDochody.addActionListener(new BudzetListener(klientView));
          buttonUsunWydatek = new JButton("Usuń wydatek");
          buttonUsunWydatek.addActionListener(new BudzetListener(klientView));
          buttonWyslijDoPliku = new JButton("Dodaj do pliku");
          buttonWyslijDoPliku.addActionListener(new BudzetListener(klientView));
          buttonWyczyscWydatki = new JButton("Wyczyść wydatki");
          buttonWyczyscWydatki.addActionListener(new BudzetListener(klientView));

          //panel lewa dol
          panelLewaDol.setLayout(new GridLayout(3,1));
          panelLewaDol.add(textFieldLewaDolPodsumowanieWydatkow);
          panelLewaDol.add(mojeDochodyLewa);
            //panel lewa dol dol dol
            panelLewaDolDol = new JPanel();
            panelLewaDolDol.setLayout(new GridLayout(2,1));
            panelLewaDolDol.add(podsumowanieLewaDol);
            panelLewaDolDol.add(buttonPodsumowanieLewaDol);
            buttonPodsumowanieLewaDol.addActionListener(new BudzetListener(klientView));
          panelLewaDol.add(panelLewaDolDol);

          //dodanie do panel srodek dol
          wszystkiePrzyciskiSrodekPanel.setLayout(new GridLayout(3,3));
          wszystkiePrzyciskiSrodekPanel.add(buttonDodajWydatki);
          wszystkiePrzyciskiSrodekPanel.add(kwotaWydatku);
            //ogarniecie panela radioButtonów
            grupaPrzyciskowWydatekPanel.setLayout(new GridLayout(3,1));
            grupaPrzyciskowWydatekPanel.add(radioButtonZywnosc);
            radioButtonZywnosc.setSelected(true);
            grupaPrzyciskowWydatekPanel.add(radioButtonMieszkanie);
            grupaPrzyciskowWydatekPanel.add(radioButtonInne);
          wszystkiePrzyciskiSrodekPanel.add(grupaPrzyciskowWydatekPanel);



          wszystkiePrzyciskiSrodekPanel.add(buttonDodajDochody);
          wszystkiePrzyciskiSrodekPanel.add(kwotaDochodu);
          wszystkiePrzyciskiSrodekPanel.add(buttonWyczyscDochody);
          wszystkiePrzyciskiSrodekPanel.add(buttonUsunWydatek);
          wszystkiePrzyciskiSrodekPanel.add(buttonWyczyscWydatki);
          wszystkiePrzyciskiSrodekPanel.add(textFieldPanelSrodekDolPrawy);

          //panel prawa dol
          panelPrawaDol.add(buttonPobierzOdPartnera);
          panelPrawaDol.add(buttonWyslijDoPliku);


          //dodanie elementów do grida
          add(mojeWydatkiLewaScrol);
          add(wydatkiWspolneSrodekZPliku);
          add(partneraWydatkiPrawaScroll);
          add(panelLewaDol);
          add(wszystkiePrzyciskiSrodekPanel);
          add(panelPrawaDol);


          //ustawienie domyslnych
          //po lewej
          mojeWydatkiLewa.setEditable(false);
          mojeWydatkiLewa.setLineWrap(true);
          mojeWydatkiLewa.setBorder(new TitledBorder(new LineBorder(Color.DARK_GRAY), "Moje wydatki:"));

          mojeDochodyLewa.setEditable(false);
          mojeDochodyLewa.setBorder(new TitledBorder(new LineBorder(Color.DARK_GRAY), "Moje dochody:"));
          textFieldLewaDolPodsumowanieWydatkow.setEditable(false);
          textFieldLewaDolPodsumowanieWydatkow.setBorder(new TitledBorder(new LineBorder(Color.DARK_GRAY), "Podsumowanie wydatków:"));
          //utworzenie fonta:
            Font font = new Font("Courier", Font.BOLD, 20);
            Font font1 = new Font("Courier", Font.BOLD, 15);
          textFieldLewaDolPodsumowanieWydatkow.setFont(font);
          textFieldLewaDolPodsumowanieWydatkow.setHorizontalAlignment(JTextField.CENTER);
          mojeDochodyLewa.setFont(font);
          mojeDochodyLewa.setBackground(Color.WHITE);
          mojeDochodyLewa.setHorizontalAlignment(JTextField.CENTER);
          mojeWydatkiLewa.setFont(font1);
          textFieldPanelSrodekDolPrawy.setBorder(new TitledBorder(new LineBorder(Color.DARK_GRAY), "Podpowiedzi:"));
          //ustawienie domyslnych
          //po prawej
          partneraWydatkiPrawa.setEditable(false);
          partneraWydatkiPrawa.setHorizontalAlignment(JTextField.CENTER);
          partneraWydatkiPrawa.setFont(font);
          partneraWydatkiPrawa.setBackground(Color.WHITE);
          wydatkiWspolneSrodekZPliku.setHorizontalAlignment(JLabel.CENTER);
          wydatkiWspolneSrodekZPliku.setFont(font);
          wydatkiWspolneSrodekZPliku.setBorder(new TitledBorder(new LineBorder(Color.DARK_GRAY), "Podsumowanie wspólnych wydatków:"));

          //srodek panel prawy dol dol
          textFieldPanelSrodekDolPrawy.setEditable(false);
          textFieldPanelSrodekDolPrawy.setLineWrap(true);
          textFieldPanelSrodekDolPrawy.setText("");

          wydatkiWspolneSrodekZPliku.setHorizontalAlignment(SwingConstants.CENTER);
          partneraWydatkiPrawa.setBorder(new TitledBorder(new LineBorder(Color.DARK_GRAY), "Podsumowanie wydatków od partnera:"));




          //dodanie mouse listenera
          buttonDodajWydatki.addMouseListener(new MouseAdapter() {
              @Override
              public void mouseEntered(MouseEvent e) {
                  super.mouseEntered(e);
                  getTextFieldPanelSrodekDolPrawy().setText("Tym dodajesz nowy wydatek");

              }
          });
          buttonDodajWydatki.addMouseListener(new MouseAdapter() {
              @Override
              public void mouseExited(MouseEvent e) {
                  super.mouseExited(e);
                  getTextFieldPanelSrodekDolPrawy().setText("");

              }
          });
          buttonDodajDochody.addMouseListener(new MouseAdapter() {
              @Override
              public void mouseEntered(MouseEvent e) {
                  super.mouseEntered(e);
                  getTextFieldPanelSrodekDolPrawy().setText("Tym dodajesz nowy dochod");
              }
          });
          buttonDodajDochody.addMouseListener(new MouseAdapter() {
              @Override
              public void mouseExited(MouseEvent e) {
                  super.mouseExited(e);
                  getTextFieldPanelSrodekDolPrawy().setText("");
              }
          });
          buttonWyczyscDochody.addMouseListener(new MouseAdapter() {
              @Override
              public void mouseEntered(MouseEvent e) {
                  super.mouseEntered(e);
                  getTextFieldPanelSrodekDolPrawy().setText("Tym czyscisz pole dochody");
              }
          });
          buttonWyczyscDochody.addMouseListener(new MouseAdapter() {
              @Override
              public void mouseExited(MouseEvent e) {
                  super.mouseExited(e);
                  getTextFieldPanelSrodekDolPrawy().setText("");
              }
          });
          buttonUsunWydatek.addMouseListener(new MouseAdapter() {
              @Override
              public void mouseEntered(MouseEvent e) {
                  super.mouseEntered(e);
                  getTextFieldPanelSrodekDolPrawy().setText("Tym usuwasz wydatek z listy");
              }
          });
          buttonUsunWydatek.addMouseListener(new MouseAdapter() {
              @Override
              public void mouseExited(MouseEvent e) {
                  super.mouseExited(e);
                  getTextFieldPanelSrodekDolPrawy().setText("");
              }
          });
          buttonWyczyscWydatki.addMouseListener(new MouseAdapter() {
              @Override
              public void mouseEntered(MouseEvent e) {
                  super.mouseEntered(e);
                  getTextFieldPanelSrodekDolPrawy().setText("Tym czyscisz liste wydatkow");
              }
          });
          buttonWyczyscWydatki.addMouseListener(new MouseAdapter() {
              @Override
              public void mouseExited(MouseEvent e) {
                  super.mouseExited(e);
                  getTextFieldPanelSrodekDolPrawy().setText("");
              }
          });

      }
    }
}
