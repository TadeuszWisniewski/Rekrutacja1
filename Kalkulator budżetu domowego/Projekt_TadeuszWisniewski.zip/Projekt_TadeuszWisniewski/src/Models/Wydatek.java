package Models;

public class Wydatek extends OperacjaFinansowa{
    private String kategoriaWydatku;

    public String getKategoriaWydatku() {
        return kategoriaWydatku;
    }

    public void setKategoriaWydatku(String kategoriaWydatku) {
        this.kategoriaWydatku = kategoriaWydatku;
    }

    public Wydatek(String kwotaOperacji, String kategoriaWydatku) {
        super(kwotaOperacji);
        this.kategoriaWydatku = kategoriaWydatku;
    }
    public String toString(){
        return super.toString()+ " " + kategoriaWydatku;
    }

}
