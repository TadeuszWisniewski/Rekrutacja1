package Models;

import java.util.ArrayList;

public class WydatkiKontener {
    private ArrayList<Wydatek> listaWydatkow;
    public WydatkiKontener() {
        listaWydatkow = new ArrayList<>();
    }

    public ArrayList<Wydatek> getListaWydatkow() {
        return listaWydatkow;
    }
    public void dodajDoLIstyWydatkow(Wydatek wydatek){
        listaWydatkow.add(wydatek);
    }
    public int zwrocWartoscWszystkichElemSume(){
        int wynik = 0;
        for (Wydatek w : listaWydatkow){
            wynik=wynik+Integer.parseInt(w.getKwotaOperacji());

        }
        return wynik;
    }
    public void wyczyscListeWydatkow(){
        listaWydatkow.clear();
    }
}
