package Models;

public class OperacjaFinansowa {
    private String kwotaOperacji;

    public String getKwotaOperacji() {
        return kwotaOperacji;
    }

    public void setKwotaOperacji(String kwotaOperacji) {
        this.kwotaOperacji = kwotaOperacji;
    }

    public OperacjaFinansowa(String kwotaOperacji) {
        this.kwotaOperacji = kwotaOperacji;
    }
    public String toString(){
        return kwotaOperacji;
    }
}
