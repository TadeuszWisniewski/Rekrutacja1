import View.KlientView;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        KlientView kalkulator = new KlientView();
        KlientView kalkulator1 = new KlientView();
    }
}