package Listeners;

import Models.Wydatek;
import Models.WydatkiKontener;
import Threads.KlientThread;
import View.KlientView;

import javax.swing.*;
import javax.swing.event.MouseInputAdapter;
import java.awt.event.*;
import java.io.*;
import java.sql.SQLOutput;
import java.util.Scanner;

public class BudzetListener  implements ActionListener {
    private final KlientView klientView;

    final JFileChooser fc = new JFileChooser();

    public BudzetListener(KlientView klientView) {
        this.klientView = klientView;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        switch (e.getActionCommand()){
            case "Dodaj":
                dodajListener();
                break;
            case "Dodaj dochody":
                dodajDochodyListener();
                break;
            case "Dodaj do pliku":
                dodajDoPlikuListener();
                break;
            case "Pokaz podsumowanie":
                pokazPodsumowanieListener();
                break;
            case "Wyczyść":
                wyczyscDochodyListener();
                break;
            case "Wyczyść wydatki":
                wyczyscWydatkiListener();
                break;
            case "Usuń wydatek":
                usunWydatekListener();
                break;

        }
    }
    public void dodajListener(){
        String kwotaWydatku = "";
        //sprawdzenie czy dobra wartosc
        try{
            Integer.parseInt(klientView.getKwotaWydatku().getText());
            kwotaWydatku = klientView.getKwotaWydatku().getText();
        }catch (Exception e){
            kwotaWydatku = bledneDane();
            if(Integer.parseInt(kwotaWydatku)==-1){
                JOptionPane.showMessageDialog(null, "Podano niewlasciwe dane", " Błąd", JOptionPane.WARNING_MESSAGE);

                klientView.getKwotaWydatku().setText("");
                klientView.getRadioButtonZywnosc().setSelected(true);

                return;
            }
        }

        String kategoriaWydatku = "";

        if(klientView.getRadioButtonZywnosc().isSelected()){
            //System.out.println("wybrano zywnosc");
            kategoriaWydatku="Żywność";
        }else if(klientView.getRadioButtonMieszkanie().isSelected()){
            //System.out.println("wybrano mieszkanie");
            kategoriaWydatku="Mieszkanie";
        } else if (klientView.getRadioButtonInne().isSelected()) {
            //System.out.println("wybrano inne");
            kategoriaWydatku="Inne";
        }
        System.out.println(kategoriaWydatku + " " + kwotaWydatku);


        Wydatek wydatek = new Wydatek(kwotaWydatku, kategoriaWydatku);
        klientView.getWydatkiKontener().dodajDoLIstyWydatkow(wydatek);


        //oczyszczenie pola po lewej
        klientView.getMojeWydatkiLewa().setText("");
        //dodanie do listy po lewej
        int i = 0;
        for(Wydatek w : klientView.getWydatkiKontener().getListaWydatkow()){
            i++;
            klientView.getMojeWydatkiLewa().append(i + ". " + w.toString() + "\n");
        }
        //wyczyszczenie pola i kategorii
        klientView.getKwotaWydatku().setText("");
        klientView.getRadioButtonZywnosc().setSelected(true);

        //dodanie do podsumowania
        //do podsumowania:
        if(klientView.getWydatkiKontener().zwrocWartoscWszystkichElemSume()==0){
            klientView.getTextFieldLewaDolPodsumowanieWydatkow().setText("");
        }else{
            klientView.getTextFieldLewaDolPodsumowanieWydatkow().setText(klientView.getWydatkiKontener().zwrocWartoscWszystkichElemSume()+"");
        }
    }

    public void dodajDochodyListener(){
        String kwotaDochodu = "";
        //sprawdzenie danych
        try{
            Integer.parseInt(klientView.getKwotaDochodu().getText());
            kwotaDochodu = klientView.getKwotaDochodu().getText();
        }catch (Exception e){
            kwotaDochodu = bledneDane();
            if(Integer.parseInt(kwotaDochodu)==-1){
                JOptionPane.showMessageDialog(null, "Podano niewlasciwe dane", " Błąd", JOptionPane.WARNING_MESSAGE);

                klientView.getKwotaDochodu().setText("");
                return;
            }
        }

        int dochodyTMP1;

        //przy pierwszym wprowadzeniu:
        if(klientView.getMojeDochodyLewa().getText().isEmpty()){
            klientView.getMojeDochodyLewa().setText(kwotaDochodu);
        }
        else{//potem juz tak:
            dochodyTMP1 = Integer.parseInt(klientView.getMojeDochodyLewa().getText());
            int dochodyTMP2 = Integer.parseInt(kwotaDochodu);
            int dochodyTMP = dochodyTMP1+dochodyTMP2;
            klientView.getMojeDochodyLewa().setText(dochodyTMP+"");
        }
        klientView.getKwotaDochodu().setText("");
    }
    public void pokazPodsumowanieListener(){
        if((klientView.getMojeWydatkiLewa().getText()).isEmpty() || klientView.getMojeDochodyLewa().getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Brak wartosci w polu wydatki lub dochody", "Błąd", JOptionPane.WARNING_MESSAGE);

        }else{
            //tutaj liczę:
            int wynik = klientView.getWydatkiKontener().zwrocWartoscWszystkichElemSume();
            int procentowo= (wynik*100)/Integer.parseInt(klientView.getMojeDochodyLewa().getText());
            klientView.getPodsumowanieLewaDol().setText("Wydano: "+ procentowo+"% dochodów.");
        }
    }

    public void wyczyscDochodyListener(){
        if(klientView.getMojeDochodyLewa().getText().isEmpty()){
            //tu wpisac
            JOptionPane.showMessageDialog(null, "Pusta lista dochodow!", "Błąd", JOptionPane.WARNING_MESSAGE);
            return;
        }
        klientView.getMojeDochodyLewa().setText("");
        klientView.getPodsumowanieLewaDol().setText("");
    }
    public void wyczyscWydatkiListener(){
        if(klientView.getWydatkiKontener().getListaWydatkow().isEmpty()){
            JOptionPane.showMessageDialog(null, "Pusta lista wydatków!", "Błąd", JOptionPane.WARNING_MESSAGE);
            return;
        }
        klientView.getMojeWydatkiLewa().setText("");
        klientView.getWydatkiKontener().wyczyscListeWydatkow();
        klientView.getPodsumowanieLewaDol().setText("");

        //sprawdzam
        for(Wydatek w : klientView.getWydatkiKontener().getListaWydatkow()){
            System.out.println(w.toString());
        }

        //do podsumowania:
        if(klientView.getWydatkiKontener().zwrocWartoscWszystkichElemSume()==0){
            klientView.getTextFieldLewaDolPodsumowanieWydatkow().setText("");
        }else{
            klientView.getTextFieldLewaDolPodsumowanieWydatkow().setText(klientView.getWydatkiKontener().zwrocWartoscWszystkichElemSume()+"");
        }
    }
    public void usunWydatekListener(){
        if(klientView.getWydatkiKontener().getListaWydatkow().isEmpty()){
            JOptionPane.showMessageDialog(null, "Pusta lista wydatków!", "Błąd", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int i=0;
        try{
            i = Integer.parseInt(JOptionPane.showInputDialog("Podaj numer indeksu do usunięcia: "));
            if(i>klientView.getWydatkiKontener().getListaWydatkow().size()){//tutaj zmienilem
                JOptionPane.showMessageDialog(null, "Niepoprawny index!", "Błąd", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Niepoprawny index!", "Błąd", JOptionPane.WARNING_MESSAGE);
            return;
        }
        klientView.getMojeWydatkiLewa().setText("");
        klientView.getWydatkiKontener().getListaWydatkow().remove((i-1));

        int j = 0;
        for(Wydatek w : klientView.getWydatkiKontener().getListaWydatkow()){
            j++;
            klientView.getMojeWydatkiLewa().append(j + ". " + w.toString() + "\n");
        }

        //do podsumowania:
        if(klientView.getWydatkiKontener().zwrocWartoscWszystkichElemSume()==0){
            klientView.getTextFieldLewaDolPodsumowanieWydatkow().setText("");
            klientView.getPodsumowanieLewaDol().setText("");
        }else{
            klientView.getTextFieldLewaDolPodsumowanieWydatkow().setText(klientView.getWydatkiKontener().zwrocWartoscWszystkichElemSume()+"");
        }
    }
    public void dodajDoPlikuListener(){
       try{
           File aktualny = new File("C:\\Users\\Gebruiker\\IdeaProjects\\Projekt_TadeuszWisniewski\\src\\PlikiDoProgramu");
           fc.setCurrentDirectory(aktualny);
           JOptionPane.showMessageDialog(null, "Można wybierać tylko z tego folderu!", "Folder", JOptionPane.INFORMATION_MESSAGE);
           int returnVal = fc.showOpenDialog(klientView);
           if (returnVal == JFileChooser.APPROVE_OPTION) {
               File file = fc.getSelectedFile();
               if(file.getAbsolutePath().equals("C:\\Users\\Gebruiker\\IdeaProjects\\Projekt_TadeuszWisniewski\\src\\PlikiDoProgramu\\Dane.txt") || file.getAbsolutePath().equals("C:\\Users\\Gebruiker\\IdeaProjects\\Projekt_TadeuszWisniewski\\src\\PlikiDoProgramu\\Dane1.txt")){
                   DataOutputStream out = new DataOutputStream(
                           new FileOutputStream(file.getAbsolutePath()));
                   //sprawdzenie wartosci
                   if(klientView.getTextFieldLewaDolPodsumowanieWydatkow().getText().isEmpty()){
                       //tu wpisac
                       JOptionPane.showMessageDialog(null, "Puste pole z wydatkami!", "Błąd", JOptionPane.WARNING_MESSAGE);
                       return;
                   }
                   if(klientView.getPartneraWydatkiPrawa().getText().isEmpty()){
                       //tu wpisac
                       JOptionPane.showMessageDialog(null, "Nie pobrano wydatkow od partnera lub są one puste ", "Błąd", JOptionPane.WARNING_MESSAGE);
                       return;
                   }
                   out.writeInt((Integer.parseInt(klientView.getTextFieldLewaDolPodsumowanieWydatkow().getText())+Integer.parseInt(klientView.getPartneraWydatkiPrawa().getText())));
                   DataInputStream in = new DataInputStream(
                           new FileInputStream( file.getAbsolutePath()));
                   String s = in.readInt()+"";
                   klientView.getWydatkiWspolneSrodekZPliku().setText(s);
                   in.close();
                   out.close();
               }else{
                   JOptionPane.showMessageDialog(null, "Niepoprawny plik!", "Błąd", JOptionPane.WARNING_MESSAGE);
                   return;
               }
           } else {
               System.out.println("Nic nie wybrano");
           }
        }catch (Exception e){
            System.out.println("Błąd przy dodawaniu do pliku" + e.getMessage());
        }
    }


    //obsluga wyjatku przy wprowadzaniu wartosci
    public String bledneDane(){
        int dobreDane = 0;
        try {
            dobreDane = Integer.parseInt(JOptionPane.showInputDialog("Podaj właściwe dane:"));
            return dobreDane+"";
        }catch (Exception e){
            return (-1)+"";
        }
    }
}
